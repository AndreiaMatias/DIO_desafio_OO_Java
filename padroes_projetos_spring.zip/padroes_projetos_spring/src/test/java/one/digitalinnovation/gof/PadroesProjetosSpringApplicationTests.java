package one.digitalinnovation.gof;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PadroesProjetosSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
